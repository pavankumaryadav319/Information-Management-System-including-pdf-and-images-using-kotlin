package com.example.addfolder

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class pdffolder : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var deleteButton: Button
    private lateinit var selectedFile: File
    private var fileList: MutableList<File> = mutableListOf()

    private val pdfFolderPath by lazy {
        File(getExternalFilesDir(null), "PDFs")
    }

    private val deletedFolderPath by lazy {
        File(getExternalFilesDir(null), "RecentlyDeletedPDFs")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdffolder)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarPdf)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        listView = findViewById(R.id.listPdf)
        deleteButton = findViewById(R.id.btnDelete)

        if (!pdfFolderPath.exists()) pdfFolderPath.mkdirs()
        if (!deletedFolderPath.exists()) deletedFolderPath.mkdirs()

        loadFiles()

        listView.setOnItemClickListener { _, _, position, _ ->
            selectedFile = fileList[position]
            Toast.makeText(this, "Opening: ${selectedFile.name}", Toast.LENGTH_SHORT).show()

            val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", selectedFile)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            try {
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "No app found to open PDF", Toast.LENGTH_SHORT).show()
            }
        }

        deleteButton.setOnClickListener {
            if (::selectedFile.isInitialized && selectedFile.exists()) {
                val dest = File(deletedFolderPath, selectedFile.name)
                selectedFile.copyTo(dest, overwrite = true)
                selectedFile.delete()
                Toast.makeText(this, "Moved to Recently Deleted", Toast.LENGTH_SHORT).show()
                loadFiles()
            } else {
                Toast.makeText(this, "No file selected!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadFiles() {
        fileList = pdfFolderPath.listFiles { file ->
            file.extension.lowercase() == "pdf"
        }?.toMutableList() ?: mutableListOf()

        val fileNames = if (fileList.isNotEmpty()) {
            fileList.map { it.name }
        } else {
            listOf("No PDF files found.")
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, fileNames)
        listView.adapter = adapter
    }
}
