package com.example.addfolder

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class imagefolder : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var deleteButton: Button
    private lateinit var selectedFile: File
    private var fileList: MutableList<File> = mutableListOf()

    private val imageFolderPath by lazy {
        File(getExternalFilesDir(null), "Images")
    }

    private val deletedImageFolderPath by lazy {
        File(getExternalFilesDir(null), "RecentlyDeletedImages")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imagefolder)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarImage)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        listView = findViewById(R.id.listImages)
        deleteButton = findViewById(R.id.btnDeleteImage)

        if (!imageFolderPath.exists()) imageFolderPath.mkdirs()
        if (!deletedImageFolderPath.exists()) deletedImageFolderPath.mkdirs()

        loadFiles()

        listView.setOnItemClickListener { _, _, position, _ ->
            selectedFile = fileList[position]
            Toast.makeText(this, "Opening: ${selectedFile.name}", Toast.LENGTH_SHORT).show()

            val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", selectedFile)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "image/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            try {
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "No app found to open image", Toast.LENGTH_SHORT).show()
            }
        }

        deleteButton.setOnClickListener {
            if (::selectedFile.isInitialized && selectedFile.exists()) {
                val dest = File(deletedImageFolderPath, selectedFile.name)
                selectedFile.copyTo(dest, overwrite = true)
                selectedFile.delete()
                Toast.makeText(this, "Moved to Recently Deleted", Toast.LENGTH_SHORT).show()
                loadFiles()
            } else {
                Toast.makeText(this, "No image selected!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadFiles() {
        fileList = imageFolderPath.listFiles {
                file -> file.extension.lowercase() in listOf("jpg", "jpeg", "png")
        }?.toMutableList() ?: mutableListOf()

        val fileNames = if (fileList.isNotEmpty()) {
            fileList.map { it.name }
        } else {
            listOf("No Image files found.")
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, fileNames)
        listView.adapter = adapter
    }
}
