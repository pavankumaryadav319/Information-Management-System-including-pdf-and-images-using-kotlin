package com.example.addfolder

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private val PICK_IMAGE_REQUEST = 1
    private val PICK_PDF_REQUEST = 2

    private val imageFolder by lazy { File(getExternalFilesDir(null), "Images") }
    private val pdfFolder by lazy { File(getExternalFilesDir(null), "PDFs") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (!imageFolder.exists()) imageFolder.mkdirs()
        if (!pdfFolder.exists()) pdfFolder.mkdirs()

        findViewById<ImageButton>(R.id.btnImages).setOnClickListener {
            startActivity(Intent(this, imagefolder::class.java))
        }

        findViewById<Button>(R.id.btnPickImage).setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "image/*"
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        findViewById<ImageButton>(R.id.btnPdf).setOnClickListener {
            startActivity(Intent(this, pdffolder::class.java))
        }

        findViewById<Button>(R.id.btnPickPdf).setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "application/pdf"
            startActivityForResult(intent, PICK_PDF_REQUEST)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val uri = data.data!!
            val fileName = getFileName(uri)
            val folder = when (requestCode) {
                PICK_IMAGE_REQUEST -> imageFolder
                PICK_PDF_REQUEST -> pdfFolder
                else -> return
            }
            val destFile = File(folder, fileName)
            contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(destFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            Toast.makeText(this, "$fileName saved!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "unknown"
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                name = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))

            }
        }
        return name
    }
}
