package com.example.project

import DataHelper
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class ViewData : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_view_data)
        val textView = findViewById<TextView>(R.id.textViewData)
        val dbHelper = DataHelper(this)
        val cursor = dbHelper.getAllData()

        val data = StringBuilder()
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getString(cursor.getColumnIndexOrThrow("user_id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("user_name"))
                data.append("ID: $id\nName: $name\n\n")
            } while (cursor.moveToNext())
        } else {
            data.append("No data found.")
        }
        cursor.close()

        textView.text = data.toString()
    }
}