package com.example.project

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ViewNotesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var noteAdapter: NoteAdapter
    private lateinit var dbHelper: NoteDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_notes)

        // Initialize views
        recyclerView = findViewById(R.id.recyclerView)
        val fab = findViewById<FloatingActionButton>(R.id.fabAddNote)
        val backButton = findViewById<ImageButton>(R.id.btnBack)

        // Back button click listener
        backButton.setOnClickListener {
            finish()
        }

        // FAB click listener to add a new text note
        fab.setOnClickListener {
            val intent = Intent(this, AddNoteActivity::class.java)
            startActivity(intent)
        }

        // Load and set up notes in RecyclerView
        dbHelper = NoteDatabaseHelper(this)
        val notes = dbHelper.getAllNotes().toMutableList()

        noteAdapter = NoteAdapter(notes) { note ->
            dbHelper.deleteNote(note.id)
            noteAdapter.removeNote(note)
            Toast.makeText(this, "Note Deleted", Toast.LENGTH_SHORT).show()
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = noteAdapter
    }
}
