package com.example.project

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NoteDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "Notes.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "CREATE TABLE Notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, alarm_time LONG)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS Notes")
        onCreate(db)
    }

    fun insertNote(title: String, desc: String, alarmTime: Long): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("title", title)
            put("description", desc)
            put("alarm_time", alarmTime)
        }
        return db.insert("Notes", null, values)
    }

    fun deleteNote(id: Int): Boolean {
        val db = writableDatabase
        val result = db.delete("Notes", "id=?", arrayOf(id.toString()))
        db.close()
        return result > 0
    }

    fun updateNoteTime(noteId: Int, time: Long): Boolean {
        val db = writableDatabase
        val contentValues = ContentValues().apply {
            put("alarm_time", time)
        }
        val result = db.update("Notes", contentValues, "id = ?", arrayOf(noteId.toString()))
        db.close()
        return result > 0
    }

    fun getAllNotes(): List<Note> {
        val notes = mutableListOf<Note>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM Notes", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val title = cursor.getString(cursor.getColumnIndexOrThrow("title"))
                val description = cursor.getString(cursor.getColumnIndexOrThrow("description"))
                val alarmTime = cursor.getLong(cursor.getColumnIndexOrThrow("alarm_time"))

                notes.add(Note(id, title, description, alarmTime))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return notes
    }
}
