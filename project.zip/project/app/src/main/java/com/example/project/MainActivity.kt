package com.example.project

import android.app.ActivityOptions
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: NoteDatabaseHelper
    private var selectedTime: Long = 0
    private var tempNoteId: Int = -1
    private var tempTitle: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTitle = findViewById<EditText>(R.id.editTitle)
        val editDesc = findViewById<EditText>(R.id.editDescription)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnView = findViewById<Button>(R.id.btnViewNotes)
        val btnSetAlarm = findViewById<Button>(R.id.btnSetAlarm)

        dbHelper = NoteDatabaseHelper(this)

        btnSetAlarm.setOnClickListener {
            val title = editTitle.text.toString()
            val desc = editDesc.text.toString()

            if (title.isEmpty() || desc.isEmpty()) {
                Toast.makeText(this, "Please enter Title and Description first", Toast.LENGTH_SHORT).show()
            } else {
                openTimePicker(title, desc)
            }
        }

        btnSave.setOnClickListener {
            val title = editTitle.text.toString()
            val desc = editDesc.text.toString()

            if (title.isNotEmpty() && desc.isNotEmpty()) {
                tempTitle = title
                AlertDialog.Builder(this)
                    .setTitle("Set Alarm?")
                    .setMessage("Do you want to set an alarm for this note?")
                    .setPositiveButton("Yes") { _, _ ->
                        tempNoteId = dbHelper.insertNote(title, desc, 0).toInt()
                        openTimePicker(title, desc)
                    }
                    .setNegativeButton("No") { _, _ ->
                        dbHelper.insertNote(title, desc, 0)
                        Toast.makeText(this, "Note Saved!", Toast.LENGTH_SHORT).show()
                        editTitle.text.clear()
                        editDesc.text.clear()
                        selectedTime = 0
                    }
                    .create()
                    .show()
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

        btnView.setOnClickListener {
            val passwordInput = EditText(this).apply {
                hint = "Enter Password"
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            }

            AlertDialog.Builder(this)
                .setTitle("Password Required")
                .setMessage("Please enter the password to view your notes.")
                .setView(passwordInput)
                .setPositiveButton("OK") { _, _ ->
                    val enteredPassword = passwordInput.text.toString()
                    if (enteredPassword == "1234") {
                        val intent = Intent(this, ViewNotesActivity::class.java)
                        val options = ActivityOptions.makeSceneTransitionAnimation(this)
                        startActivity(intent, options.toBundle())
                    } else {
                        Toast.makeText(this, "Incorrect Password!", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .create()
                .show()
        }
    }

    private fun openTimePicker(title: String, desc: String) {
        val cal = Calendar.getInstance()
        val timePicker = TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hourOfDay)
                cal.set(Calendar.MINUTE, minute)
                cal.set(Calendar.SECOND, 0)
                selectedTime = cal.timeInMillis

                if (tempNoteId != -1) {
                    dbHelper.updateNoteTime(tempNoteId, selectedTime)
                    setAlarm(tempTitle, selectedTime, tempNoteId)
                }

                Toast.makeText(this, "Note & Alarm Saved!", Toast.LENGTH_SHORT).show()
                findViewById<EditText>(R.id.editTitle).text.clear()
                findViewById<EditText>(R.id.editDescription).text.clear()
                selectedTime = 0
                tempNoteId = -1
            },
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE),
            true
        )
        timePicker.show()
    }

    private fun setAlarm(title: String, time: Long, requestCode: Int) {
        val alarmMgr = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra("note_title", title)
        }

        val alarmIntent = PendingIntent.getBroadcast(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmMgr.setExact(AlarmManager.RTC_WAKEUP, time, alarmIntent)
    }
}
