package com.example.project

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class NoteAdapter(
    private val notes: MutableList<Note>,
    private val onDeleteClick: (Note) -> Unit
) : RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {

    class NoteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.noteTitle)
        val desc: TextView = view.findViewById(R.id.noteDesc)
        val alarmTimeText: TextView = view.findViewById(R.id.alarmTimeText)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.itemnote, parent, false)
        return NoteViewHolder(view)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val note = notes[position]

        holder.title.text = note.title
        holder.desc.text = note.description

        if (note.alarmTime > 0) {
            val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
            holder.alarmTimeText.text = sdf.format(Date(note.alarmTime))
        } else {
            holder.alarmTimeText.text = "No Alarm"
        }

        holder.btnDelete.setOnClickListener {
            onDeleteClick(note)
        }
    }

    override fun getItemCount() = notes.size

    fun removeNote(note: Note) {
        val index = notes.indexOf(note)
        if (index != -1) {
            notes.removeAt(index)
            notifyItemRemoved(index)
        }
    }

    fun addNote(note: Note) {
        notes.add(0, note)
        notifyItemInserted(0)
    }
}
