package com.example.project

data class Note(
    val id: Int,
    val title: String,
    val description: String,
    val alarmTime: Long
)
