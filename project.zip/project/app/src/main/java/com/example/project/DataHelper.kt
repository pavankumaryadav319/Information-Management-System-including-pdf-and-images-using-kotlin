
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DataHelper(context: Context) :
    SQLiteOpenHelper(context, "UserData.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("CREATE TABLE UserInfo(user_id TEXT PRIMARY KEY, user_name TEXT, reminder_time TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS UserInfo")
        onCreate(db)
    }

    fun insertData(name: String, id: String) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("user_id", id)
            put("user_name", name)
        }
        db.insert("UserInfo", null, values)
    }

    fun getAllData(): Cursor {
        val db = readableDatabase
        return db.rawQuery("SELECT * FROM UserInfo", null)
    }

    fun updateUserName(userId: String, newName: String): Boolean {
        val db = writableDatabase
        val contentValues = ContentValues().apply {
            put("user_name", newName)
        }
        val result = db.update("UserInfo", contentValues, "user_id = ?", arrayOf(userId))
        return result > 0
    }

    fun updateReminderTime(userId: String, time: String): Boolean {
        val db = writableDatabase
        val contentValues = ContentValues().apply {
            put("reminder_time", time)
        }
        val result = db.update("UserInfo", contentValues, "user_id = ?", arrayOf(userId))
        return result > 0
    }
}
